a = input("Enter a number: ")
a = int(a)  # convert a to an integer(if possible)
print(type(a))