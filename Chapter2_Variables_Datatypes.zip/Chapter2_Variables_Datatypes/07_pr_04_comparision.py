a = 34
b = 80
print("is a greater than b:",a>b)