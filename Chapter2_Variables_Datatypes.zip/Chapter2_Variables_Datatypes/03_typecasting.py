a = "3534"
a = int(a) 
print(type(a)) 
print(a + 5)