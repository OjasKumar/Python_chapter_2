a = 2
b = 3
print("The sum of a and b is", a+b)
