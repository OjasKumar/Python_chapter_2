a = input("Enter a number: ")
a = int(a)
square = a*a
print("The square of the number is", square)